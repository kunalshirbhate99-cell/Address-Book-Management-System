#include <stdio.h>
#include "file.h"

// Saves all contacts from the address book into a CSV file
void saveContactsToFile(AddressBook *addressBook)
{
    // Store the total number of contacts
    int limit = addressBook->contactCount;

    // Open the CSV file in write mode
    FILE *fp = fopen("addressbook.csv", "w+");

    // Check whether the file was opened successfully
    if(fp == NULL)
    {
        printf("File doesn't exist\n");
        return;
    }

    // Write each contact's details into the file
    for(int i = 0; i < limit; i++)
    {
        fprintf(fp, "%s,%s,%s\n",addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);
    }

    // Close the file after saving all contacts
    fclose(fp);
}


// Loads contacts from the CSV file into the address book
void loadContactsFromFile(AddressBook *addressBook)
{
    int i = 0;

    // Open the CSV file in read mode
    FILE *fp = fopen("addressbook.csv", "r");

    // Check whether the file was opened successfully
    if(fp == NULL)
    {
        printf("File doesn't exist\n");
        return;
    }

    // Read contact details from the file until the end of the file
    while(fscanf(fp, "%49[^,],%19[^,],%49[^\n]\n", addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email) == 3)
    {
        // Move to the next contact
        i++;
    }

    // Update the total number of contacts
    addressBook->contactCount = i;

    // Close the file after loading all contacts
    fclose(fp);
}
