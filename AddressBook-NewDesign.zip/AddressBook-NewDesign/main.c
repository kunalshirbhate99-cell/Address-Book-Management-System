#include <stdio.h>
#include "contact.h"

int main()
{
    int choice;
    AddressBook addressBook;

    // Initialize the address book
    initialize(&addressBook);

    // Display the menu until the user chooses to exit
    do
    {
        printf("\n");
        printf(" +--------------------------------+\n");
        printf(" |        ADDRESS BOOK MENU       |\n");
        printf(" +--------------------------------+\n");
        printf(" |  1. Create Contact             |\n");
        printf(" |  2. Search Contact             |\n");
        printf(" |  3. Edit Contact               |\n");
        printf(" |  4. Delete Contact             |\n");
        printf(" |  5. List All Contacts          |\n");
        printf(" |  6. Exit                       |\n");
        printf(" +--------------------------------+\n");

        // Get the user's choice
        printf("\n Enter your choice: ");
        scanf("%d", &choice);

        // Perform the operation according to the user's choice
        switch(choice)
        {
            case 1:
                // Create a new contact
                createContact(&addressBook);
                break;

            case 2:
                // Search for a contact
                searchContact(&addressBook);
                break;

            case 3:
                // Edit an existing contact
                editContact(&addressBook);
                break;

            case 4:
                // Delete a contact
                deleteContact(&addressBook);
                break;

            case 5:
                // Display all contacts
                listContacts(&addressBook);
                break;

            case 6:
                // Save contacts before exiting
                printf("\n");
                printf(" +--------------------------------------+\n");
                printf(" |         Saving and Exiting...        |\n");
                printf(" +--------------------------------------+\n");

                saveContactsToFile(&addressBook);

                break;

            default:
                // Handle invalid menu choice
                printf("\n Invalid choice. Please try again.\n");
        }

    } while(choice != 6);

    return 0;
}
