
#ifndef CONTACT_H
#define CONTACT_H

// Maximum number of contacts that can be stored in the address book
#define MAX_CONTACTS 100

// Structure to store details of a single contact
typedef struct {

    char name[50];      // Stores contact name
    char phone[20];     // Stores contact phone number
    char email[50];     // Stores contact email address

} Contact;


// Structure to store all contacts and the total number of contacts
typedef struct {

    Contact contacts[MAX_CONTACTS];  // Array of contacts
    int contactCount;                // Number of contacts currently stored

} AddressBook;


// Creates a new contact and adds it to the address book
void createContact(AddressBook *addressBook);

// Searches for a contact using different search options
void searchContact(AddressBook *addressBook);

// Edits the details of an existing contact
void editContact(AddressBook *addressBook);

// Deletes a contact from the address book
void deleteContact(AddressBook *addressBook);

// Displays all contacts stored in the address book
void listContacts(AddressBook *addressBook);

// Initializes the address book
void initialize(AddressBook *addressBook);

// Saves all contacts to a file
void saveContactsToFile(AddressBook *AddressBook);


// Validates the contact name
int validateName(char *name);

// Validates the phone number
int validatePhone(char *phone,AddressBook *addressBook);

// Checks whether the phone number is unique
int isPhoneUnique(char *phone, AddressBook *addressBook);

// Validates the email address
int validateEmail(char *email,AddressBook *addressBook);

// Checks whether the email address is unique
int isEmailUnique(char *email, AddressBook *addressBook);


// Searches contacts by name
void searchByName(AddressBook *addressBook);

// Searches contacts by phone number
void searchByPhone(AddressBook *addressBook);

// Searches contacts by email address
void searchByEmail(AddressBook *addressBook);


// Searches a contact by name before editing
void editbyname(AddressBook *addressBook);

// Edits the name of a selected contact
void editname(AddressBook *addressBook,int i);

// Edits the phone number of a selected contact
void editphone(AddressBook *addressBook,int i);

// Edits the email address of a selected contact
void editemail(AddressBook *addressBook,int i);

// Checks phone number uniqueness while editing a contact
int isPhoneUniqueEdit(char *phone, AddressBook *addressBook, int i);

// Checks email uniqueness while editing a contact
int isEmailUniqueEdit(char *email, AddressBook *addressBook, int i);

// Searches a contact by phone number before editing
void editbyphone(AddressBook *addressBook);

// Searches a contact by email before editing
void editbyemail(AddressBook *addressBook);


// Searches a contact by name before deleting
void deletebyname(AddressBook *addressBook);

// Searches a contact by phone number before deleting
void deletebyphone(AddressBook *addressBook);

// Asks for confirmation before deleting a contact
int confirmdelte(AddressBook *addressBook,int i);

// Searches a contact by email before deleting
void deletebyemail(AddressBook *addressBook);

#endif

