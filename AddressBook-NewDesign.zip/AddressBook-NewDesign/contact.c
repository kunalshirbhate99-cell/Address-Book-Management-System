#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "contact.h"
#include "file.h"
#include "populate.h"

void listContacts(AddressBook *addressBook)
{
    printf("\n");
    printf(" +--------------------------------------------------------------------------------+\n");
    printf(" |                              LIST OF CONTACTS                                  |\n");
    printf(" +-------------------------+----------------+-------------------------------------+\n");
    printf(" | Name                    | Phone          | Email                               |\n");
    printf(" +-------------------------+----------------+-------------------------------------+\n");

    if(addressBook->contactCount == 0)
    {
        printf(" |                              No Contacts Found !!!                             |\n");
    }
    else
    {
        for(int i = 0; i < addressBook->contactCount; i++)
        {
            printf(" | %-23s | %-14s | %-35s |\n",addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);
        }
    }

    printf(" +-------------------------+----------------+-------------------------------------+\n");
}

void initialize(AddressBook *addressBook) {
    addressBook->contactCount = 0;
    //populateAddressBook(addressBook);
    //Load contacts from file during initialization (After files)
    loadContactsFromFile(addressBook);
}

void saveAndExit(AddressBook *addressBook) 
{
    saveContactsToFile(addressBook); // Save contacts to file
    exit(EXIT_SUCCESS); // Exit the program
}

void createContact(AddressBook *addressBook)
{
    int i = addressBook->contactCount;

    if(i >= 99)
    {
        printf("\n +--------------------------------------+\n");
        printf(" |      Maximum Contact Reached !!!     |\n");
        printf(" +--------------------------------------+\n");
        return;
    }

    printf("\n +--------------------------------------+\n");
    printf(" |            CREATE CONTACT            |\n");
    printf(" +--------------------------------------+\n");

    int attemptn = 0;
    while(attemptn < 3)
    {
        printf("\n Enter the Name = ");
        scanf(" %[^\n]", addressBook->contacts[i].name);

        if(validateName(addressBook->contacts[i].name))
            break;

        attemptn++;

        if(attemptn == 3)
        {
            printf("\n Maximum Attempt Reached For Name !!!\n");
            return;
        }
    }


    int attemptp = 0;
    while(attemptp < 3)
    {
        printf(" Enter the Phone Number = ");
        scanf(" %[^\n]", addressBook->contacts[i].phone);

        if(validatePhone(addressBook->contacts[i].phone, addressBook))
        {
            if(isPhoneUnique(addressBook->contacts[i].phone, addressBook))
            break;
        }

        attemptp++;

        if(attemptp == 3)
        {
            printf("\n Maximum Attempt for Phone Number Reached !!!\n");
            return;
        }
    }


    int attempte = 0;
    while(attempte < 3)
    {
        printf(" Enter the Email = ");
        scanf(" %[^\n]", addressBook->contacts[i].email);

        if(validateEmail(addressBook->contacts[i].email, addressBook))
        {
            if(isEmailUnique(addressBook->contacts[i].email, addressBook))
            break;
        }

        attempte++;

        if(attempte == 3)
        {
            printf("\n Maximum Attempt for Email Reached !!!\n");
            return;
        }
    }

    addressBook->contactCount++;

    printf("\n +--------------------------------------+\n");
    printf(" |          Contact Saved !!!           |\n");
    printf(" +--------------------------------------+\n");
}

void searchContact(AddressBook *addressBook)
{
    while(1)
    {
        printf("\n");
        printf(" +--------------------------------+\n");
        printf(" |          SEARCH CONTACT        |\n");
        printf(" +--------------------------------+\n");
        printf(" |  1. Search By Name             |\n");
        printf(" |  2. Search By Phone Number     |\n");
        printf(" |  3. Search By Email            |\n");
        printf(" |  4. Back                       |\n");
        printf(" +--------------------------------+\n");

        printf("\n Enter your choice: ");

        int choice;
        scanf(" %d", &choice);

        switch(choice)
        {
            case 1:
                searchByName(addressBook);
                break;

            case 2:
                searchByPhone(addressBook);
                break;

            case 3:
                searchByEmail(addressBook);
                break;

            case 4:
                return;

            default:
                printf("\n Invalid choice. Please try again.\n");
        }
    }
}

void editContact(AddressBook *addressBook)
{
    if(addressBook->contactCount == 0)
    {
        printf("\n +--------------------------------------+\n");
        printf(" |       No Contacts Saved !!!          |\n");
        printf(" +--------------------------------------+\n");
        return;
    }
    
    while(1)
    {
        printf("\n");
        printf(" +--------------------------------+\n");
        printf(" |           EDIT CONTACT         |\n");
        printf(" +--------------------------------+\n");
        printf(" |  1. Edit By Name               |\n");
        printf(" |  2. Edit By Phone Number       |\n");
        printf(" |  3. Edit By Email              |\n");
        printf(" |  4. Back                       |\n");
        printf(" +--------------------------------+\n");

        printf("\n Enter your choice: ");

        int choice;
        scanf(" %d", &choice);

        switch(choice)
        {
            case 1:
                editbyname(addressBook);
                break;

            case 2:
                editbyphone(addressBook);
                break;

            case 3:
                editbyemail(addressBook);
                break;

            case 4:
                return;

            default:
                printf("\n Invalid choice. Please try again.\n");
        }
    }
}
void deleteContact(AddressBook *addressBook)
{
    if(addressBook->contactCount == 0)
    {
        printf("\n +--------------------------------------+\n");
        printf(" |       No Contacts Saved !!!          |\n");
        printf(" +--------------------------------------+\n");
        return;
    }

    while(1)
    {
        printf("\n");
        printf(" +--------------------------------+\n");
        printf(" |          DELETE CONTACT        |\n");
        printf(" +--------------------------------+\n");
        printf(" |  1. Delete By Name             |\n");
        printf(" |  2. Delete By Phone Number     |\n");
        printf(" |  3. Delete By Email            |\n");
        printf(" |  4. Back                       |\n");
        printf(" +--------------------------------+\n");

        printf("\n Enter your choice: ");

        int choice;
        scanf(" %d", &choice);

        switch(choice)
        {
            case 1:
                deletebyname(addressBook);
                break;

            case 2:
                deletebyphone(addressBook);
                break;

            case 3:
                deletebyemail(addressBook);
                break;

            case 4:
                return;

            default:
                printf("\n Invalid choice. Please try again.\n");
        }
    }
}
int validateName(char *name)
{
    int len = strlen(name);

    if(len < 3)
    {
        printf("Name must contain atleast 3 character\n");
        return 0;
    }

    for(int j = 0; j < len; j++)
    {
        if(!(isalpha(name[j]) || name[j] == ' '))
        {
            printf("Name should contain only alphabets\n");
            return 0;
        }
    }

    return 1;
}
int validatePhone(char *phone,AddressBook *addressBook)
{
    int len = strlen(phone);

    if(len != 10)
    {
        printf("Phone Number Should contain exactly 10 numbers\n");
        return 0;
    }

    if(!(phone[0] >= '6' && phone[0] <= '9'))
    {
        printf("First Digit must be between 6 to 9\n");
        return 0;
    }

    for(int j = 0; j < len; j++)
    {
        if(!isdigit(phone[j]))
        {
            printf("Other than Digits any other Character not allowed in phone number\n");
            return 0;
        }
    }
    return 1;
}
int isPhoneUnique(char *phone, AddressBook *addressBook)
{
    for(int k = 0; k < addressBook->contactCount; k++)
    {
        if(strcmp(phone, addressBook->contacts[k].phone) == 0)
        {
            printf("\n Phone Number Must be Unique !!!\n");
            return 0;
        }
    }
    return 1;
}
int validateEmail(char *email,AddressBook *addressBook)
{
    int len = strlen(email);
    int pos = 0;
    int counts = 0;

    for(int j = 0; j < len; j++)
    {
        if(!((isalnum(email[j])) || email[j] == '@' || email[j] == '.'))
        {
            printf("Only alphabets and Numbers are allowed in Email\n");
            return 0;
        }
    }

    for(int k = 0; k < len; k++)
    {
        if(email[k] == '@')
        {
            pos = k;
            counts++;
        }
    }

    if(counts != 1)
    {
        printf("Missing @\n");
        return 0;
    }

    char *domain = strstr(email, ".com");

    if(domain == NULL)
    {
        printf("No domain\n");
        return 0;
    }
    else
    {
        int dot = domain - email;

        if(dot == pos + 1)
        {
            printf("At least one character required between @ and .com\n");
            return 0;
        }

        if(domain[4] != '\0')
        {
            printf("Extra Characters after .com\n");
            return 0;
        }
    }
    return 1;
}
int isEmailUnique(char *email, AddressBook *addressBook)
{
    for(int k = 0; k < addressBook->contactCount; k++)
    {
        if(strcmp(email, addressBook->contacts[k].email) == 0)
        {
            printf("\n Email Must be Unique !!!\n");
            return 0;
        }
    }

    return 1;
}
void searchByName(AddressBook *addressBook)
{
    if(addressBook->contactCount == 0)
    {
        printf("\n +--------------------------------------+\n");
        printf(" |          No Contacts Saved !!!       |\n");
        printf(" +--------------------------------------+\n");
        return;
    }

    char name[100];

    printf("\n Enter the Name = ");
    scanf(" %[^\n]", name);

    int count = 0;

    for(int i = 0; i < addressBook->contactCount; i++)
    {
        if(strcmp(name, addressBook->contacts[i].name) == 0)
        {
            count++;
        }
    }

    if(count == 0)
    {
        printf("\n +--------------------------------------+\n");
        printf(" |          No Contact Found !!!        |\n");
        printf(" +--------------------------------------+\n");
        return;
    }

    if(count > 1)
    {
        printf("\n Multiple Contacts Found !!!\n");
        printf(" \n Please Enter Phone Number or Email Id !!");
        return;
    }

    for(int i = 0; i < addressBook->contactCount; i++)
    {
        if(strcmp(name, addressBook->contacts[i].name) == 0)
        {
            printf("\n +--------------------------------------+\n");
            printf(" |           CONTACT DETAILS            |\n");
            printf(" +--------------------------------------+\n");
            printf(" | Name  = %-27s |\n", addressBook->contacts[i].name);
            printf(" | Phone = %-27s |\n", addressBook->contacts[i].phone);
            printf(" | Email = %-27s |\n", addressBook->contacts[i].email);
            printf(" +--------------------------------------+\n");
            return;
        }
    }
}
void searchByPhone(AddressBook *addressBook)
{
    if(addressBook->contactCount == 0)
    {
        printf("\n +--------------------------------------+\n");
        printf(" |          No Contacts Saved !!!       |\n");
        printf(" +--------------------------------------+\n");
        return;
    }

    char phone[100];

    printf("\n Enter the Phone Number = ");
    scanf(" %[^\n]", phone);

    int count = 0;

    for(int i = 0; i < addressBook->contactCount; i++)
    {
        if(strcmp(phone, addressBook->contacts[i].phone) == 0)
        {
            printf("\n +--------------------------------------+\n");
            printf(" |           CONTACT DETAILS            |\n");
            printf(" +--------------------------------------+\n");
            printf(" | Name  = %-27s |\n", addressBook->contacts[i].name);
            printf(" | Phone = %-27s |\n", addressBook->contacts[i].phone);
            printf(" | Email = %-27s |\n", addressBook->contacts[i].email);
            printf(" +--------------------------------------+\n");

            count = 1;
            break;
        }
    }

    if(count == 0)
    {
        printf("\n +--------------------------------------+\n");
        printf(" |          No Contact Found !!!        |\n");
        printf(" +--------------------------------------+\n");
    }
}
void searchByEmail(AddressBook *addressBook)
{
    if(addressBook->contactCount == 0)
    {
        printf("\n +--------------------------------------+\n");
        printf(" |          No Contacts Saved !!!       |\n");
        printf(" +--------------------------------------+\n");
        return;
    }

    char email[100];

    printf("\n Enter the Email Id = ");
    scanf(" %[^\n]", email);

    int count = 0;

    for(int i = 0; i < addressBook->contactCount; i++)
    {
        if(strcmp(email, addressBook->contacts[i].email) == 0)
        {
            printf("\n +--------------------------------------+\n");
            printf(" |           CONTACT DETAILS            |\n");
            printf(" +--------------------------------------+\n");
            printf(" | Name  = %-27s |\n", addressBook->contacts[i].name);
            printf(" | Phone = %-27s |\n", addressBook->contacts[i].phone);
            printf(" | Email = %-27s |\n", addressBook->contacts[i].email);
            printf(" +--------------------------------------+\n");

            count = 1;
            break;
        }
    }

    if(count == 0)
    {
        printf("\n +--------------------------------------+\n");
        printf(" |          No Contact Found !!!        |\n");
        printf(" +--------------------------------------+\n");
    }
}
void editbyname(AddressBook *addressBook)
{
    char name[100];

    printf("\n  Enter Name of Contact You Want to Edit = ");
    scanf(" %[^\n]", name);

    int count = 0;

    for(int i = 0; i < addressBook->contactCount; i++)
    {
        if(strcmp(name, addressBook->contacts[i].name) == 0)
        {
            count++;
        }
    }

    if(count == 0)
    {
        printf("\n +--------------------------------------+\n");
        printf(" |       No Contact Found !!!           |\n");
        printf(" +--------------------------------------+\n");
        return;
    }

    if(count > 1)
    {
        printf("\n Multiple Contacts Found !!!\n");
        printf(" \n Please Enter Phone Number or Email Id !!");
        return;
    }

    for(int i = 0; i < addressBook->contactCount; i++)
    {
        if(strcmp(name, addressBook->contacts[i].name) == 0)
        {
            while(1)
            {
                printf("\n");
                printf(" +--------------------------------------+\n");
                printf(" |       SELECT FIELD TO EDIT           |\n");
                printf(" +--------------------------------------+\n");
                printf(" |  1. Edit Name                        |\n");
                printf(" |  2. Edit Phone Number                |\n");
                printf(" |  3. Edit Email Id                    |\n");
                printf(" |  4. Back                             |\n");
                printf(" +--------------------------------------+\n");

                int option;
                printf("\n Enter the option: ");
                scanf(" %d", &option);

                switch(option)
                {
                    case 1:
                        editname(addressBook, i);
                        break;

                    case 2:
                        editphone(addressBook, i);
                        break;

                    case 3:
                        editemail(addressBook, i);
                        break;

                    case 4:
                        return;

                    default:
                        printf("\n Invalid choice. Please try again.\n");
                }
            }
        }
    }
}
void editname(AddressBook *addressBook, int i)
{
    while(1)
    {
        printf("\n Enter the New Name = ");
        scanf(" %[^\n]", addressBook->contacts[i].name);

        if(validateName(addressBook->contacts[i].name))
        {
            printf("\n +--------------------------------------+\n");
            printf(" |            Name Edited !!!           |\n");
            printf(" +--------------------------------------+\n");
            return;
        }
    }
}
void editphone(AddressBook *addressBook, int i)
{
    while(1)
    {
        printf("\n Enter the New Phone Number = ");
        scanf(" %[^\n]", addressBook->contacts[i].phone);

        if(validatePhone(addressBook->contacts[i].phone, addressBook))
        {
            if(isPhoneUniqueEdit(addressBook->contacts[i].phone, addressBook, i))
            {
                printf("\n +--------------------------------------+\n");
                printf(" |         Phone Number Edited !!!      |\n");
                printf(" +--------------------------------------+\n");
                return;
            }
        }
    }
}
void editemail(AddressBook *addressBook, int i)
{
    while(1)
    {
        printf("\n Enter the New Email Id = ");
        scanf(" %[^\n]", addressBook->contacts[i].email);

        if(validateEmail(addressBook->contacts[i].email, addressBook))
        {
            if(isEmailUniqueEdit(addressBook->contacts[i].email, addressBook, i))
            {
                printf("\n +--------------------------------------+\n");
                printf(" |           Email Edited !!!           |\n");
                printf(" +--------------------------------------+\n");
                return;
            }
        }
    }
}
int isPhoneUniqueEdit(char *phone, AddressBook *addressBook, int i)
{
    for(int k = 0; k < addressBook->contactCount; k++)
    {
        if(k == i)
        continue;

        if(strcmp(phone, addressBook->contacts[k].phone) == 0)
        {
            printf("\nPhone Number Must be Unique !!!\n");
            return 0;
        }
    }

    return 1;
}
int isEmailUniqueEdit(char *email, AddressBook *addressBook, int i)
{
    for(int k = 0; k < addressBook->contactCount; k++)
    {
        if(k == i)
            continue;

        if(strcmp(email, addressBook->contacts[k].email) == 0)
        {
            printf("\nEmail Must be Unique !!!\n");
            return 0;
        }
    }

    return 1;
}
void editbyphone(AddressBook *addressBook)
{
    char Phone[100];
    printf(" Enter Phone of contact you want to edit =");
    scanf(" %[^\n]",Phone);
    int count =0;
    
    for(int i=0;i<addressBook->contactCount;i++)
    {
        if(strcmp(Phone,addressBook->contacts[i].phone)==0)
        {
            
            while(1)
            {
               printf("\n");
                printf(" +--------------------------------------+\n");
                printf(" |       SELECT FIELD TO EDIT           |\n");
                printf(" +--------------------------------------+\n");
                printf(" |  1. Edit Name                        |\n");
                printf(" |  2. Edit Phone Number                |\n");
                printf(" |  3. Edit Email Id                    |\n");
                printf(" |  4. Back                             |\n");
                printf(" +--------------------------------------+\n");

                int option;
                printf("\n Enter the option: ");
                scanf(" %d",&option);

                switch(option)
                {
                    case 1:
                    editname(addressBook,i);
                    break;

                    case 2:
                    editphone(addressBook,i);
                    break;

                    case 3:
                    editemail(addressBook,i);
                    break;

                    case 4:
                    return;

                    default:
                    printf("Please select from above option!!!\n");
                }

            }
            count =1;
        }
    }
        if (count==0)
        {
            printf("Please Enter correct Information !!\n");
        }
}
void editbyemail(AddressBook *addressBook)
{
    char email[100];
    printf(" Enter Email of contact you want to edit =");
    scanf(" %[^\n]",email);
    int count =0;
    
    for(int i=0;i<addressBook->contactCount;i++)
    {
        if(strcmp(email,addressBook->contacts[i].email)==0)
        {
            
            while(1)
            {
                printf("\n");
                printf(" +--------------------------------------+\n");
                printf(" |       SELECT FIELD TO EDIT           |\n");
                printf(" +--------------------------------------+\n");
                printf(" |  1. Edit Name                        |\n");
                printf(" |  2. Edit Phone Number                |\n");
                printf(" |  3. Edit Email Id                    |\n");
                printf(" |  4. Back                             |\n");
                printf(" +--------------------------------------+\n");
                
                int option;
                printf("\n Enter the option: ");
                scanf(" %d",&option);

                switch(option)
                {
                    case 1:
                    editname(addressBook,i);
                    break;

                    case 2:
                    editphone(addressBook,i);
                    break;

                    case 3:
                    editemail(addressBook,i);
                    break;

                    case 4:
                    return;

                    default:
                    printf("Please select from above option!!!\n");
                }

            }
            count = 1;
        }    
    }
        if (count==0)
        {
            printf("Please Enter correct Information !!\n");
        }
}
void deletebyname(AddressBook *addressBook)
{
    char name[100];

    printf("\n Enter the Name of Contact You Want to Delete = ");
    scanf(" %[^\n]", name);

    int count = 0;

    for(int i = 0; i < addressBook->contactCount; i++)
    {
        if(strcmp(name, addressBook->contacts[i].name) == 0)
        {

            count++;
        }
    }

    if(count == 0)
    {
        printf("\n +--------------------------------------+\n");
        printf(" |       No Contact Found !!!           |\n");
        printf(" +--------------------------------------+\n");
        return;
    }

    if(count > 1)
    {
        printf("\n Multiple Contacts Found !!!\n");
        printf(" \n Please Enter Phone Number or Email Id !!");
        return;
    }

    for(int i = 0; i < addressBook->contactCount; i++)
    {
        if(strcmp(name, addressBook->contacts[i].name) == 0)
        {
            if(confirmdelte(addressBook, i) == 0)
                return;

            for(int j = i; j < addressBook->contactCount - 1; j++)
            {
                addressBook->contacts[j] = addressBook->contacts[j + 1];
            }

            addressBook->contactCount--;

            printf("\n +--------------------------------------+\n");
            printf(" |       Contact Deleted !!!            |\n");
            printf(" +--------------------------------------+\n");

            return;
        }
    }
}
void deletebyphone(AddressBook *addressBook)
{
    char phone[100];

    printf("\n Enter the Phone Number of Contact You Want to Delete = ");
    scanf(" %[^\n]", phone);

    int count = 0;

    for(int i = 0; i < addressBook->contactCount; i++)
    {
        if(strcmp(phone, addressBook->contacts[i].phone) == 0)
        {
            if(confirmdelte(addressBook, i) == 0)
                return;

            for(int j = i; j < addressBook->contactCount - 1; j++)
            {
                addressBook->contacts[j] = addressBook->contacts[j + 1];
            }

            addressBook->contactCount--;
            count = 1;

            printf("\n +--------------------------------------+\n");
            printf(" |       Contact Deleted !!!            |\n");
            printf(" +--------------------------------------+\n");

            break;
        }
    }

    if(count == 0)
    {
        printf("\n +--------------------------------------+\n");
        printf(" |       No Contact Found !!!           |\n");
        printf(" +--------------------------------------+\n");
    }
}
void deletebyemail(AddressBook *addressBook)
{
    char email[100];

    printf("\n Enter the Email Id of Contact You Want to Delete = ");
    scanf(" %[^\n]", email);

    int count = 0;

    for(int i = 0; i < addressBook->contactCount; i++)
    {
        if(strcmp(email, addressBook->contacts[i].email) == 0)
        {
            if(confirmdelte(addressBook, i) == 0)
                return;

            for(int j = i; j < addressBook->contactCount - 1; j++)
            {
                addressBook->contacts[j] = addressBook->contacts[j + 1];
            }

            addressBook->contactCount--;
            count = 1;

            printf("\n +--------------------------------------+\n");
            printf(" |       Contact Deleted !!!            |\n");
            printf(" +--------------------------------------+\n");

            break;
        }
    }

    if(count == 0)
    {
        printf("\n +--------------------------------------+\n");
        printf(" |       No Contact Found !!!           |\n");
        printf(" +--------------------------------------+\n");
    }
}
int confirmdelte(AddressBook *addressBook, int i)
{
    printf("\n");
    printf(" +--------------------------------------+\n");
    printf(" |          CONTACT DETAILS             |\n");
    printf(" +--------------------------------------+\n");
    printf(" | Name  = %-27s |\n", addressBook->contacts[i].name);
    printf(" | Phone = %-27s |\n", addressBook->contacts[i].phone);
    printf(" | Email = %-27s |\n", addressBook->contacts[i].email);
    printf(" +--------------------------------------+\n");

    while(1)
    {
        char choice;

        printf("\n Enter Y to Continue / N to Return = ");
        scanf(" %c", &choice);

        choice = toupper(choice);

        switch(choice)
        {
            case 'Y':
                return 1;

            case 'N':
                return 0;

            default:
                printf("\n Please select Y or N !!!\n");
        }
    }  
}

